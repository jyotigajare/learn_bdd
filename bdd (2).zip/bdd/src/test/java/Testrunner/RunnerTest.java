package Testrunner;




	import io.cucumber.junit.CucumberOptions;

			
	@CucumberOptions(
		
			features= {"Features"},
			glue= {"StepDefiniations.com"}
			
			)
	public class RunnerTest 
	{

	


	}


