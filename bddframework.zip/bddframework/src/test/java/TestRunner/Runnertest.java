package TestRunner;

import io.cucumber.testng.CucumberOptions;
@CucumberOptions(
		
		features= {"Features"},
		glue= {"StepDefiniations.com"}
		
		)
public class Runnertest{
}



	
	


