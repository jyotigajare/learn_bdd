package stepdefination;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class Step7 {

	@Given("praful sir start the automation testing class")
	public void praful_sir_start_the_automation_testing_class() {
	  System.out.println("praful sir start the class");
	  
	}

	@When("student join the class")
	public void student_join_the_class() {
	   System.out.println("student join the class");
	   
	}

	@When("start the class on zoom meeting")
	public void start_the_class_on_zoom_meeting() {
	   System.out.println("start the class on zoom meeting"); 
	}

	}


